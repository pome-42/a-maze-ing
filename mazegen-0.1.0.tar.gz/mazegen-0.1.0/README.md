*This project has been created as part of the 42 curriculum by pomeeeeeeeene.*

# A-Maze-ing

## Description

A-Maze-ing generates validated perfect or non-perfect mazes, writes them in
the subject format, finds a shortest route, and can display the result with
MiniLibX. The generation core is also available as the installable `mazegen`
Python package.

## Instructions

Install the locked development environment with:

```bash
make install
```

Generate a maze from the only command-line argument, a configuration file:

```bash
uv run python a_maze_ing.py config.txt
# or
make run
```

The configuration uses `KEY=VALUE` lines. The required keys are `WIDTH`,
`HEIGHT`, `ENTRY`, `EXIT`, `OUTPUT_FILE`, and `PERFECT`; `SEED` is optional.
`ENTRY` and `EXIT` are written as `x,y`, and `PERFECT` must be exactly `True`
or `False`. Lines beginning with `#` and blank lines are ignored.

The output contains one lowercase hexadecimal wall value per cell, followed by
the entry, exit, and shortest path. Wall bits are ordered N/E/S/W as 1/2/4/8.

When the MLX window is available, the controls are:

| Key | Action |
| --- | --- |
| `1` / `R` | Generate and display a new maze |
| `2` / `P` | Show or hide the shortest path |
| `3` / `C` | Cycle wall color |
| `4` / `Esc` / close | Exit and release resources |

## Reusable API

Build the distribution with `make build`. This creates a `mazegen-*.whl` and
source archive in the repository root. A consumer can then install the wheel
and use the public API without the CLI or MLX:

```python
from mazegen import MazeGenerator

result = MazeGenerator(
    25,
    20,
    seed=42,
    perfect=False,
    entry=(0, 0),
    exit=(24, 19),
).generate()

print(result.grid)       # immutable wall snapshots
print(result.pattern_cells)
print(result.solution)   # shortest path using N/E/S/W
```

`MazeResult` also exposes `width`, `height`, `entry`, `exit`, `seed`, and
`pattern_omitted`. Reusing the same dimensions, options, and seed reproduces
the same result.

## Algorithm and design

The core uses a seeded iterative depth-first traversal to create a spanning
tree. Non-perfect mode opens additional safe walls and independently validates
connectivity, loops, dead ends, the 42 mask, and corridor-width constraints.
Breadth-first search provides a shortest route. The seed, grid, pattern
placement, and route are kept as immutable result snapshots at the public API
boundary.

## Resources and development notes

The subject PDF and the included `maze_analyzer.py` were used as references;
the latter is treated as an analysis tool rather than as the model API. Codex
was used to assist with implementation, tests, packaging, and documentation;
the design decisions and validation rules are recorded in `AGENTS.md` and the
implementation documents.

Run the complete automated checks with:

```bash
make test
make lint
make lint-strict
```

The repository currently contains the single-member implementation. The
additional MLX display controls and the reusable `mazegen` package are
documented here as implemented features.
